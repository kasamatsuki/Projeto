//
// Created by vasco on 05/06/2024.
//

#ifndef HEADERS_VIEWS_VIEW_H_
#define HEADERS_VIEWS_VIEW_H_
#include <string>

using namespace std;

class View{
public:
    View();
    int menuPrincipal();
    int menuGeral();
    int menuUser();
    int receitasMenu();
    int ingredientesStockMenu();
    int ingredientesMenu();
    int restricoesMenu();




};

#endif //TRABALHO_DE_FSOFT_VIEW_H
