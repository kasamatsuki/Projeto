//
// Created by diogo on 16/06/2024.
//
#include <iostream>
#include "Controller.h"
#include "Utils.h"
#include "InvalidDataException.h"

Controller::Controller(FoodFinder& foodFinder) {
    this->model = foodFinder;
}
void Controller::run() {
    int op = -1;
    if(this->loggedUser == nullptr){
        do{
            op = this->view.menuPrincipal();
            switch(op){
                case 1:runLogin(); //2 - Login
                    break;
                case 2:runCreateAccount(); //3 - Sign up
                    break;
                default:
                    break;
            }
        }while(op != 0);
    }else{

        menuGeral();
    }
}

void Controller::runLogin(){


    string username = this->clientView.getUsername();
    string password = this->clientView.getPassword();

    // Obter cliente pelo nome de usuário
    ClientList& clientList = model.getClientList();
    Client* tempClient = clientList.getByUsername(username);

    // Verificar se o cliente existe
    if (tempClient == nullptr) {
        this-> clientView.invalidUsername();
        return;
    }

    // Verificar se a senha corresponde
    if(tempClient->doesPasswordMatch(password)){
        this->login((User*)tempClient);
        cout<<"Login Successful";
        menuGeral();
    }else{
        this->clientView.incorrectPassword();
    }
}
void Controller::runCreateAccount() {
    ClientList& clientList = this->model.getClientList();
    string username = this->clientView.getUsername();

    if(clientList.getByUsername(username) != nullptr){
        cout << "Username already taken.";
        return;
    }
    string password = this->clientView.getPassword();
    Client newClient(username, password);
    clientList.addClient(newClient);
}

void Controller::login(User* pUser) {
    this->loggedUser = pUser;
}

void Controller::logout() {
    if(this->loggedUser == nullptr){
        cout<<"No account is logged in";
        return;
    }
    this->loggedUser = nullptr;
}

void Controller::runGeral() {
    int op = -1;
    auto* loggedClient = (Client*)this->loggedUser;
    do{
        op = this->view.menuPrincipal();
        switch(op){
            case 1:
                runReceitas();     //1 - Recipes
                break;
            case 2:
                runIngredientes();                  //2 - Ingredients
                break;
            case 3:
                runRestricoes();      //3 - Restrictions
                break;
            case 4:                         //4 - User
                runUser();
                break;
            default:
                break;
        }
    }while(op != 0);
    logout();
}

void Controller::runReceitas() {
    int op = -1;
    ReceitaList& receitaList = this->model.getReceitaList();
    do {
        // Obtém todas as receitas atualizadas da lista
        list<Receita> allReceitas = receitaList.getAll();



        // Menu de receitas
        op = this->view.receitasMenu();
        switch (op) {
            case 1: // 1 - View Receitas
                this->receitaView.printReceitaList(allReceitas, "Recipes List:");
                op = -1;
                break;
            case 2: // 2 - Create Receita
                runCreateReceita();
                allReceitas = receitaList.getAll();
                op = -1;
                break;

            case 3:runEditProduct();          // 2 - Edit Receita
                this->productView.printProductListManager(products, "Products List:");
                products = productList.getAll();
                break;

                op = 0;
                break;
            default:
                break;
        }
    }while(op != 0);
}
void Controller::runViewAllRecipes(){
    ClientOrderList modelClientOrderList = this->model.getClientOrderList();

    //Checking if there are any orders placed by clients
    if(this->model.getClientOrderList().getSize(modelClientOrderList) == 0){
        this->clientOrderView.thereAreNoOrders();
        return;
    }

    this->clientOrderView.printAllClientOrders(modelClientOrderList);
}