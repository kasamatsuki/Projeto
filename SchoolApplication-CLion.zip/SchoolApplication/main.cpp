//============================================================================
// Name        : main.cpp
// Author      : pbs
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "School.h"

#include "MockData.h"
#include "Controller.h"

using namespace std;

int main() {

    School school("ISEP");

    MockData mock;
    mock.generateData(school);

    Controller controller(school);
    controller.run();
    cout << "Application has exited" << endl;
    return 0;
}
