/*
 * EnrollView.h
 *
 *  Created on: 26/04/2021
 *      Author: pbs
 */

#ifndef HEADERS_VIEWS_ENROLLVIEW_H_
#define HEADERS_VIEWS_ENROLLVIEW_H_



#include <list>
#include <tuple>
#include "Enroll.h"
#include "StudentContainer.h"
#include "SubjectContainer.h"

class EnrollView{
public:
	Enroll getEnroll(StudentContainer & students, SubjectContainer & subjects);
	void printEnroll(Enroll *enroll);
	void printEnrolls(list<Enroll>& enrolls);
	void printStudentEnrolls(Student * student, list<tuple<Subject *, int>>& subjects);
	void printSubjectEnrolls(Subject * subject, list<Student *>& students);
};


#endif /* HEADERS_VIEWS_ENROLLVIEW_H_ */
