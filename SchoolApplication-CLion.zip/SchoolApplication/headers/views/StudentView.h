/*
 * StudentView.h
 *
 *  Created on: 21/04/2021
 *      Author: pbs
 */

#ifndef HEADERS_VIEWS_STUDENTVIEW_H_
#define HEADERS_VIEWS_STUDENTVIEW_H_
#include <list>
#include "Student.h"

class StudentView{
public:
	Date getDate();
	Student getStudent();
	void printStudent(Student *student);
	void printStudents(list<Student>& students);
};




#endif /* HEADERS_VIEWS_STUDENTVIEW_H_ */
