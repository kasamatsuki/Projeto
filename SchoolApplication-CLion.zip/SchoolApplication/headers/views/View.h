/*
 * View.h
 *
 *  Created on: 21/04/2021
 *      Author: pbs
 */

#ifndef HEADERS_VIEWS_VIEW_H_
#define HEADERS_VIEWS_VIEW_H_
#include <string>

using namespace std;
class View{
public:
	View();
	int menuSchool();
	int menuStudents();
	int menuInstructors();
	int menuSubjects();
	int menuEnrolls();
	int menuLectures();


};



#endif /* HEADERS_VIEWS_VIEW_H_ */
