/*
 * SubjectView.h
 *
 *  Created on: 26/04/2021
 *      Author: pbs
 */

#ifndef HEADERS_VIEWS_SUBJECTVIEW_H_
#define HEADERS_VIEWS_SUBJECTVIEW_H_


#include <list>
#include "Subject.h"

class SubjectView{
public:
	Subject getSubject();
	void printSubject(Subject *subject);
	void printSubjects(list<Subject>& subjects);
};




#endif /* HEADERS_VIEWS_SUBJECTVIEW_H_ */
