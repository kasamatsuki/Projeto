/*
 * InstructorView.h
 *
 *  Created on: 26/04/2021
 *      Author: pbs
 */

#ifndef HEADERS_VIEWS_INSTRUCTORVIEW_H_
#define HEADERS_VIEWS_INSTRUCTORVIEW_H_

#include <list>
#include "Instructor.h"
class InstructorView{
public:
	Instructor getInstructor();
	void printInstructor(Instructor *instructor);
	void printInstructors(list<Instructor>& instructors);
};




#endif /* HEADERS_VIEWS_INSTRUCTORVIEW_H_ */
