/*
 * LectureView.h
 *
 *  Created on: 27/04/2021
 *      Author: pbs
 */


#ifndef HEADERS_VIEWS_LECTUREVIEW_H_
#define HEADERS_VIEWS_LECTUREVIEW_H_

#include <list>
#include "Lecture.h"
#include "SubjectContainer.h"

class LectureView{
public:
	Lecture getLecture(SubjectContainer & subjects);
	void printLecture(Lecture *lecture);
	void printLectures(Instructor * instructor, list<Lecture>& lectures);
};
#endif /* HEADERS_VIEWS_LECTUREVIEW_H_ */

