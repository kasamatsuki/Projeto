/*
 * Instructor.h
 *
 *  Created on: 16/04/2021
 *      Author: pbs
 */

#ifndef HEADERS_MODEL_INSTRUCTOR_H_
#define HEADERS_MODEL_INSTRUCTOR_H_

#include "Person.h"
#include "LectureContainer.h"

class Instructor : public Person{
private:
	string initials;
	LectureContainer lectures;
	bool isInitialsValid(const string& initials);
public:
	Instructor(const string& initials, const string& name);
	Instructor(const Instructor& obj);
	~Instructor();
	const string& getInitials() const ;
	void setInitials(const string &initials) ;
	LectureContainer & getLectures();
	bool operator == (const Instructor& obj) const;
	bool operator == (const string initials) const;


};


#endif /* HEADERS_MODEL_INSTRUCTOR_H_ */
