/*
 * School.h
 *
 *  Created on: 19/04/2021
 *      Author: pbs
 */

#ifndef HEADERS_MODEL_SCHOOL_H_
#define HEADERS_MODEL_SCHOOL_H_
#include <string>
#include "SubjectContainer.h"
#include "StudentContainer.h"
#include "InstructorContainer.h"
#include "EnrollContainer.h"
using namespace std;

class School{
private :
	string name;
	SubjectContainer subjects;
	StudentContainer students;
	InstructorContainer instructors;
	EnrollContainer enrolls;

	void setDataForConsistency();
public:
	School();
	School(const string& name);
	School(const School& obj);
	const string& getName() const ;
	void setName(const string &name) ;

	SubjectContainer & getSubjectContainer();
	StudentContainer & getStudentContainer();
	InstructorContainer & getInstructorContainer();
	EnrollContainer & getEnrollContainer();

};



#endif /* HEADERS_MODEL_SCHOOL_H_ */
