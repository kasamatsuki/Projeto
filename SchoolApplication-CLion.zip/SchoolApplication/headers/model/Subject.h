/*
 * Subject.h
 *
 *  Created on: 16/04/2021
 *      Author: pbs
 */

#ifndef HEADERS_MODEL_SUBJECT_H_
#define HEADERS_MODEL_SUBJECT_H_
#include <string>
using namespace std;
class Subject {
private:
	string initials;
	string designation;
	bool isInitialsValid(const string& initials);
public:
	Subject(string initials, string designation);
	Subject(const Subject& obj);
	~Subject();
	const string& getDesignation() const;
	void setDesignation(const string &designation);
	const string& getInitials() const;
	void setInitials(const string &initials);
	bool operator == (const Subject& obj) const;
	bool operator == (const string& str) const;
};


#endif /* HEADERS_MODEL_SUBJECT_H_ */
