/*
 * Enroll.h
 *
 *  Created on: 16/04/2021
 *      Author: pbs
 */

#ifndef HEADERS_MODEL_ENROLL_H_
#define HEADERS_MODEL_ENROLL_H_

#include "Subject.h"
#include "Student.h"

using namespace std;

class Enroll{
private:
	int grade;
	Subject * subject;
	Student * student;
	bool isPointerNotNull(void * ptr);
public:
	Enroll(int grade, Subject * subject, Student * student);
	Enroll(const Enroll& obj);
	~Enroll();
	int getGrade() const;
	void setGrade(int grade) ;
	Subject* getSubject() const;
	void setSubject(Subject *subject);
	Student* getStudent() const;
	void setStudent(Student *student);

	bool operator == (const Enroll& obj) const;
};



#endif /* HEADERS_MODEL_ENROLL_H_ */
