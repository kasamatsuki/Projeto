/*
 * StudentContainer.h
 *
 *  Created on: 19/04/2021
 *      Author: pbs
 */

#ifndef HEADERS_MODEL_STUDENTCONTAINER_H_
#define HEADERS_MODEL_STUDENTCONTAINER_H_

#include <list>
#include "Student.h"
#include "EnrollContainer.h"

class StudentContainer{
private:
	list<Student> students;
	list<Student>::iterator search(int number);
	EnrollContainer * enrolls;
public:
	list<Student> getAll();
	Student* get(int number);
	void add(const Student& obj);
	void remove(int number);
	void update(int number, const string& name, const Date& date);

	void setEnrolls(EnrollContainer *enrolls);
};



#endif /* HEADERS_MODEL_STUDENTCONTAINER_H_ */
