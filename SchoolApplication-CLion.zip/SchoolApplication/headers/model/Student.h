/*
 * Student.h
 *
 *  Created on: 16/04/2021
 *      Author: pbs
 */

#ifndef HEADERS_MODEL_STUDENT_H_
#define HEADERS_MODEL_STUDENT_H_

#include "Person.h"
#include "Date.h"



class Student : public Person{
private:
	static int NUMBER;
	int number;
	Date birthday;


public:
	Student(const string& name, const Date& birthday);
	Student(const Student& student);
	~Student();
	const Date& getBirthday() const;
	void setBirthday(const Date &birthday);
	int getNumber() const ;
	void setNumber(int number);

	bool operator == (const Student& obj) const;
	bool operator == (int nr) const;


};




#endif /* HEADERS_MODEL_STUDENT_H_ */
