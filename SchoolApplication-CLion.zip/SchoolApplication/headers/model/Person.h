/*
 * Person.h
 *
 *  Created on: 16/04/2021
 *      Author: pbs
 */

#ifndef HEADERS_MODEL_PERSON_H_
#define HEADERS_MODEL_PERSON_H_

#include <string>

using namespace std;

class Person{
protected:
	string name;
	bool isNameValid(const string& name);
public:
	Person(const string& name);
	Person(const Person& person);
	~Person();
	const string& getName() const;
	void setName(const string &name);
};



#endif /* HEADERS_MODEL_PERSON_H_ */
