/*
 * InstructorContainer.h
 *
 *  Created on: 19/04/2021
 *      Author: pbs
 */

#ifndef HEADERS_MODEL_INSTRUCTORCONTAINER_H_
#define HEADERS_MODEL_INSTRUCTORCONTAINER_H_


#include <list>
#include "Instructor.h"

class InstructorContainer{
private:
	list<Instructor> instructors;
	list<Instructor>::iterator search(const string& initials);
public:
	list<Instructor> getAll();
	Instructor* get(const string& initials);
	void add(const Instructor& obj);
	void remove(const string& initials);
	void update(const string& initials, const string& name);
	bool  isThereSubject(const string& initials);

};




#endif /* HEADERS_MODEL_INSTRUCTORCONTAINER_H_ */
