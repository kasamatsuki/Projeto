/*
 * SubjectContainer.h
 *
 *  Created on: 19/04/2021
 *      Author: pbs
 */

#ifndef HEADERS_MODEL_SUBJECTCONTAINER_H_
#define HEADERS_MODEL_SUBJECTCONTAINER_H_
#include <vector>
#include <list>
#include "Subject.h"
#include "EnrollContainer.h"
#include "InstructorContainer.h"

using namespace std;

class SubjectContainer{
private:
	vector<Subject> subjects;
	EnrollContainer *enrolls;
	InstructorContainer *instructors;
	int search(const string& initials);
public:
	list<Subject> getAll();
	Subject* get(const string& initials);
	void add(const Subject& obj);
	void remove(const string& initials);
	void update(const string& initials, const string& designation);

	void setEnrolls(EnrollContainer *enrolls);
	void setInstructors(InstructorContainer *instructors);
};



#endif /* HEADERS_MODEL_SUBJECTCONTAINER_H_ */
