/*
 * Lecture.h
 *
 *  Created on: 19/04/2021
 *      Author: pbs
 */

#ifndef HEADERS_MODEL_LECTURE_H_
#define HEADERS_MODEL_LECTURE_H_

#include "Subject.h"
class Lecture{
private:
	Subject * subject;
public:
	Lecture(Subject * subject);
	Lecture(const Lecture& obj);
	~Lecture();
	Subject* getSubject() const;
	void setSubject(Subject *subject);
	bool operator == (const Lecture& obj) const;
	bool operator == (const Subject* ptr) const;
};



#endif /* HEADERS_MODEL_LECTURE_H_ */
