/*
 * EnrollContainer.h
 *
 *  Created on: 19/04/2021
 *      Author: pbs
 */

#ifndef HEADERS_MODEL_ENROLLCONTAINER_H_
#define HEADERS_MODEL_ENROLLCONTAINER_H_

#include <list>
#include <tuple>
#include "Enroll.h"

using namespace std;

class EnrollContainer{
private:
	list<Enroll> enrolls;
	list<Enroll>::iterator search(int number, const string& initials);
public:
	list<Enroll> getAll();
	Enroll* get(int number, const string& initials);
	list<tuple<Subject *, int>> getSubjects(int number);
	list<Student *> getStudents(const string& initials);
	void add(const Enroll& obj);
	void remove(int number,const string& initials);
	void update(int number,const string& initials, int grade);
};



#endif /* HEADERS_MODEL_ENROLLCONTAINER_H_ */
