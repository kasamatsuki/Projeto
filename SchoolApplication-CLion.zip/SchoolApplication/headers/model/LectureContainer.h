/*
 * LectureContainer.h
 *
 *  Created on: 19/04/2021
 *      Author: pbs
 */

#ifndef HEADERS_MODEL_LECTURECONTAINER_H_
#define HEADERS_MODEL_LECTURECONTAINER_H_

#include <list>
#include "Subject.h"
#include "Lecture.h"

using namespace std;

class LectureContainer{
private:
	list<Lecture> lectures;
	list<Lecture>::iterator search(const string& initials);
public:
	list<Lecture> getAll();
	Lecture* get(const string& initials);
	void add(const Lecture& obj);
	void remove(const string& initials);

};


#endif /* HEADERS_MODEL_LECTURECONTAINER_H_ */
