/*
 * Controller.h
 *
 *  Created on: 21/04/2021
 *      Author: pbs
 */

#ifndef HEADERS_CONTROLLERS_CONTROLLER_H_
#define HEADERS_CONTROLLERS_CONTROLLER_H_


#include "View.h"
#include "EnrollView.h"
#include "InstructorView.h"
#include "StudentView.h"
#include "SubjectView.h"
#include "LectureView.h"
#include "School.h"

class Controller{

private:
	School model;
	View view;
	StudentView studentView;
	InstructorView instructorView;
	SubjectView subjectView;
	EnrollView enrollView;
	LectureView lectureView;
	void runStudents();
	void runInstructors();
	void runSubjects();
	void runEnrolls();
	void runLectures();
public:
	Controller(School& school);
	void run();
};




#endif /* HEADERS_CONTROLLERS_CONTROLLER_H_ */
