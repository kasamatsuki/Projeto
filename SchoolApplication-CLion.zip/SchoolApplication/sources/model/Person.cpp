/*
 * Person.cpp
 *
 *  Created on: 20/04/2021
 *      Author: pbs
 */
#include "Person.h"
#include "InvalidDataException.h"



bool Person::isNameValid(const string& name){
	if(name.length() < 3){
		return false;
	}
	return true;
}

Person::Person(const string& name){
	setName(name);
}
Person::Person(const Person& person){
	setName(person.name);
}

Person::~Person(){
}

const string&  Person::getName() const {
	return name;
}
void  Person::setName(const string &name) {
	if(isNameValid(name)){
		this->name = name;
	}else{

		string msg = "Person: " + name;
		throw InvalidDataException(msg);
	}
}

