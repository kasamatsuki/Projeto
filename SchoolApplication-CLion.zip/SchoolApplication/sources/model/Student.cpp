/*
 * Student.cpp
 *
 *  Created on: 16/04/2021
 *      Author: pbs
 */

#include "Student.h"

int Student::NUMBER = 0;

Student::Student(const string& name, const Date& birthday): Person(name){
	this->number = ++NUMBER;
	this->birthday = birthday;
}
Student::Student(const Student& student): Person(student.name){
	this->number = student.number;
	this->birthday = student.birthday;
}
Student::~Student(){
}
const Date& Student::getBirthday() const {
	return birthday;
}

void Student::setBirthday(const Date &birthday) {
	this->birthday = birthday;
}

int Student::getNumber() const {
	return number;
}

void Student::setNumber(int number) {
	this->number = number;
}
bool Student::operator == (const Student& obj) const{
	if(this->number == obj.number){
		return true;
	}
	return false;
}


bool Student::operator == (int nr) const{
	if(this->number == nr){
		return true;
	}
	return false;
}
