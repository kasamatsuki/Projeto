/*
 * Lecture.cpp
 *
 *  Created on: 19/04/2021
 *      Author: pbs
 */
#include "Lecture.h"
#include "InvalidDataException.h"

Lecture::Lecture(Subject* subject ){
	this->setSubject(subject);
}
Lecture::Lecture(const Lecture& obj){
	this->setSubject(obj.subject);
}
Lecture::~Lecture(){

}

Subject* Lecture::getSubject() const {
	return subject;
}

void Lecture::setSubject(Subject *subject) {

	if(subject!=NULL){
		this->subject = subject;
	}else{
		string msg = "Lecture: subject = NULL";
		throw InvalidDataException(msg);
	}
}

bool Lecture::operator == (const Lecture& obj) const{
	if(*(this->subject) == *(obj.subject)){
		return true;
	}
	return false;
}
bool Lecture::operator == (const Subject* ptr) const{
	if(*(this->subject) == *ptr){
		return true;
	}
	return false;
}

