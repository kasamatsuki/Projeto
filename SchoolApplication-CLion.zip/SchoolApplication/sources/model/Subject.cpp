/*
 * Subject.cpp
 *
 *  Created on: 16/04/2021
 *      Author: pbs
 */

#include "Subject.h"
#include "InvalidDataException.h"

bool Subject::isInitialsValid(const string& initials){
	if(initials.length() < 4){
		return false;
	}
	return true;
}
Subject::Subject(string initials, string designation){
	setInitials(initials);
	this->designation =designation;
}

Subject::Subject(const Subject& obj){
	setInitials(obj.initials);
	this->designation = obj.designation;
}

Subject::~Subject(){

}
const string& Subject::getDesignation() const {
	return designation;
}

void Subject::setDesignation(const string &designation) {
	this->designation = designation;
}

const string& Subject::getInitials() const {
	return initials;
}

void Subject::setInitials(const string &initials) {
	if(isInitialsValid(initials)){
		this->initials = initials;
	}else{

		string msg = "Instructor: " + initials;
		throw InvalidDataException(msg);
	}
}

bool Subject::operator == (const Subject& obj) const{
	if(this->initials == obj.initials){
		return true;
	}
	return false;
}
bool Subject::operator == (const string& str) const{
	if(this->initials == str){
		return true;
	}
	return false;
}
