/*
 * LectureContainer.cpp
 *
 *  Created on: 19/04/2021
 *      Author: pbs
 */

#include "DuplicatedDataException.h"
#include "LectureContainer.h"

list<Lecture>::iterator LectureContainer::search(const string& initials){
	Subject * subject;
	list<Lecture>::iterator it = this->lectures.begin();
	for (; it != this->lectures.end(); ++it){
		subject = it->getSubject();
		if(*(subject) == initials){
			return it;
		}
	}
	return it;
}
list<Lecture>  LectureContainer::getAll(){
	list<Lecture> newlist (this->lectures);
	return newlist;
}
Lecture*  LectureContainer::get(const string& initials){
	list<Lecture>::iterator it = search(initials);
	if(it != this->lectures.end()){
		return &*it;
	}
	return NULL;
}
void  LectureContainer::add(const Lecture& obj){
	Subject* subject = obj.getSubject();
	list<Lecture>::iterator it = search(subject->getInitials());
	if(it == this->lectures.end()){
		this->lectures.push_back(obj);
	}else{
		string msg = "Lecture: " + subject->getInitials();
		throw  DuplicatedDataException(msg);
	}

}
void  LectureContainer::remove(const string& initials){
	list<Lecture>::iterator it = search(initials);
	if(it != this->lectures.end()){
		this->lectures.erase(it);
	}
}


