/*
 * SubjectContainer.cpp
 *
 *  Created on: 19/04/2021
 *      Author: pbs
 */
#include "DuplicatedDataException.h"
#include "SubjectContainer.h"
#include "DataConsistencyException.h"

int SubjectContainer::search(const string& initials){
	for (unsigned i=0; i<this->subjects.size(); ++i){
		if( this->subjects[i] == initials){
			return i;
		}
	}
	return -1;
}
list<Subject> SubjectContainer::getAll(){
	list<Subject> list;
	for (vector<Subject>::iterator it = this->subjects.begin(); it != this->subjects.end(); ++it){
		list.push_back(*it);
	}
	return list;
}
Subject* SubjectContainer::get(const string& initials){
	Subject *subject = NULL;
	int i = search(initials);
	if(i != -1){
		subject= &this->subjects[i];
	}
	return subject;
}
void SubjectContainer::add(const Subject& obj){
	int i = search(obj.getInitials());
	if(i == -1){
		this->subjects.push_back(obj);
	}else{
		string msg = "Subject: " + obj.getInitials();
		throw DuplicatedDataException(msg);
	}

}
void SubjectContainer::remove(const string& initials){
	list<Student *> listEnrolls;
	bool exist;
	int i = search(initials);
	if(i != -1){
		listEnrolls = this->enrolls->getStudents(initials);
		exist = this->instructors->isThereSubject(initials);
		if(listEnrolls.size() == 0 && exist==false){
			this->subjects.erase(this->subjects.begin() + i);
		}else{
			string msg = "Subject: " + initials;
			throw DataConsistencyException(msg);

		}
	}
}
void SubjectContainer::update(const string& initials, const string& designation){
	int i = search(initials);
	if(i != -1){
		this->subjects[i].setDesignation(designation);
	}
}

void SubjectContainer::setEnrolls(EnrollContainer *enrolls){
	this->enrolls = enrolls;
}
void SubjectContainer::setInstructors(InstructorContainer *instructors){
	this->instructors = instructors;
}


