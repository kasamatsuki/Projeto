/*
 * Instructor.cpp
 *
 *  Created on: 19/04/2021
 *      Author: pbs
 */

#include "Instructor.h"
#include "InvalidDataException.h"

bool Instructor::isInitialsValid(const string& initials){
	if(initials.length() != 4){
		return false;
	}
	return true;
}

Instructor::Instructor(const string& initials, const string& name):Person(name){
	setInitials(initials);
}

Instructor::Instructor(const Instructor& obj): Person(obj.name){
	setInitials(obj.initials);
	this->lectures = obj.lectures;
}

Instructor::~Instructor(){

}

const string& Instructor::getInitials() const {
	return initials;
}

void Instructor::setInitials(const string &initials) {

	if(isInitialsValid(initials)){
		this->initials = initials;
	}else{

		string msg = "Instructor: " + initials;
		throw InvalidDataException(msg);
	}
}
LectureContainer & Instructor::getLectures(){
	return this->lectures;
}

bool Instructor::operator == (const Instructor& obj) const{
	if(this->initials == obj.initials){
		return true;
	}
	return false;
}

bool Instructor::operator == (const string initials) const{
	if(this->initials == initials){
		return true;
	}
	return false;
}




