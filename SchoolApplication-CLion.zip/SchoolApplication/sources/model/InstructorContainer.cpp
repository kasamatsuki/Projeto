/*
 * InstructorContainer.cpp
 *
 *  Created on: 19/04/2021
 *      Author: pbs
 */

#include "DuplicatedDataException.h"
#include "InstructorContainer.h"


list<Instructor>::iterator InstructorContainer::search(const string& initials){
	list<Instructor>::iterator it = this->instructors.begin();
	for (; it != this->instructors.end(); ++it){
		if((*it) == initials){
			return it;
		}
	}
	return it;
}
list<Instructor>  InstructorContainer::getAll(){
	list<Instructor> newlist (this->instructors);
	return newlist;
}
Instructor*  InstructorContainer::get(const string& initials){
	list<Instructor>::iterator it = search(initials);
	if(it != this->instructors.end()){
		return &(*it);
	}
	return NULL;
}
void  InstructorContainer::add(const Instructor& obj){
	list<Instructor>::iterator it = search(obj.getInitials());
	if(it == this->instructors.end()){
		this->instructors.push_back(obj);
	}else{
		string msg = "Instructor: " + obj.getInitials();
		throw DuplicatedDataException(msg);
	}

}
void  InstructorContainer::remove(const string& initials){
	list<Instructor>::iterator it = search(initials);
	if(it != this->instructors.end()){
		this->instructors.erase(it);
	}
}
void  InstructorContainer::update(const string& initials, const string& name){
	list<Instructor>::iterator it = search(initials);
	if(it != this->instructors.end()){
		it->setName(name);
	}
}

bool  InstructorContainer::isThereSubject(const string& initials){
	Lecture * lecture =NULL;
	for (list<Instructor>::iterator it = this->instructors.begin(); it != this->instructors.end(); ++it){
		LectureContainer& lectures = it->getLectures();
		lecture = lectures.get(initials);
		if(lecture != NULL){
			return true;
		}
	}
	return false;
}
