/*
 * School.cpp
 *
 *  Created on: 19/04/2021
 *      Author: pbs
 */
#include "School.h"

School::School(){
	this->name = "";
	setDataForConsistency();

}
School::School(const string& name){
	this->name = name;
	setDataForConsistency();
}
School::School(const School& obj){
	this->name = obj.name;

	this->subjects = obj.subjects;
	this->students = obj.students;
	this->instructors = obj.instructors;
	this->enrolls = obj.enrolls;
	setDataForConsistency();
}

const string& School::getName() const {
	return name;
}

void School::setName(const string &name) {
	this->name = name;
}

SubjectContainer & School::getSubjectContainer(){
	return this->subjects;
}
StudentContainer & School::getStudentContainer(){
	return this->students;
}
InstructorContainer & School::getInstructorContainer(){
	return this->instructors;
}
EnrollContainer & School::getEnrollContainer(){
	return this->enrolls;
}


void School::setDataForConsistency(){
	this->students.setEnrolls(&this->enrolls);
	this->subjects.setEnrolls(&this->enrolls);
	this->subjects.setInstructors(&this->instructors);
}




