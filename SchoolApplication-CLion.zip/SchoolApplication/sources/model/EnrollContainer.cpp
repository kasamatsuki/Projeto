/*
 * EnrollContainer.cpp
 *
 *  Created on: 19/04/2021
 *      Author: pbs
 */


#include "DuplicatedDataException.h"
#include "Enroll.h"
#include "EnrollContainer.h"

using namespace std;

list<Enroll>::iterator EnrollContainer::search(int number, const string& initials){

	list<Enroll>::iterator it = this->enrolls.begin();
	for (; it != this->enrolls.end(); ++it){
		Subject * subject = it->getSubject();
		Student * student = it->getStudent();
		if(student->getNumber()== number && subject->getInitials() == initials){
			return it;
		}
	}
	return it;
}
list<Enroll>  EnrollContainer::getAll(){
	list<Enroll> newlist (this->enrolls);
	return newlist;
}
Enroll*  EnrollContainer::get(int number, const string& initials){
	list<Enroll>::iterator it = search(number,initials);
	if(it != this->enrolls.end()){
		return &*it;
	}
	return NULL;
}
list<tuple<Subject *, int>> EnrollContainer::getSubjects(int number){
	list<tuple<Subject *, int>> newlist;
	for (list<Enroll>::iterator it = this->enrolls.begin(); it != this->enrolls.end(); ++it){
		Student * student = it->getStudent();
		if(student->getNumber()== number){
			tuple<Subject *, int> t = make_tuple(it->getSubject(), it->getGrade());
			 newlist.push_back(t);
		}
	}
	return newlist;
}
list<Student *> EnrollContainer::getStudents(const string& initials){
	list<Student *> newlist;
	for (list<Enroll>::iterator it = this->enrolls.begin(); it != this->enrolls.end(); ++it){
		Subject * subject = it->getSubject();
		if(subject->getInitials() == initials){
			 newlist.push_back(it->getStudent());
		}
	}
	return newlist;
}

void  EnrollContainer::add(const Enroll& obj){
	Subject* subject = obj.getSubject();
	Student * student = obj.getStudent();
	list<Enroll>::iterator it = search(student->getNumber(),subject->getInitials());
	if(it == this->enrolls.end()){
		this->enrolls.push_back(obj);
	}else{
		string msg = "Enroll: " + to_string(student->getNumber())+" " + subject->getInitials();
		throw DuplicatedDataException(msg);
	}
}
void  EnrollContainer::remove(int number, const string& initials){
	list<Enroll>::iterator it = search(number,initials);
	if(it != this->enrolls.end()){
		this->enrolls.erase(it);
	}
}
void  EnrollContainer::update(int number, const string& initials,int grade){
	list<Enroll>::iterator it = search(number, initials);
	if(it != this->enrolls.end()){
		it->setGrade(grade);
	}
}


