/*
 * StudentContainer.cpp
 *
 *  Created on: 19/04/2021
 *      Author: pbs
 */
#include <tuple>
#include "DuplicatedDataException.h"
#include "DataConsistencyException.h"
#include "StudentContainer.h"
using namespace std;

list<Student>::iterator StudentContainer::search(int number){
	list<Student>::iterator it = this->students.begin();
	for (; it != this->students.end(); ++it){
		if((*it) == number){
			return it;
		}
	}
	return it;
}
list<Student> StudentContainer::getAll(){
	list<Student> newlist (this->students);
	return newlist;
}
Student* StudentContainer::get(int number){
	list<Student>::iterator it = search(number);
	if(it != this->students.end()){
		return &(*it);
	}
	return NULL;

}
void StudentContainer::add(const Student& obj){
	list<Student>::iterator it = search(obj.getNumber());
	if(it == this->students.end()){
		this->students.push_back(obj);
	}else{
		string msg = "Student: " + to_string(obj.getNumber());
		throw DuplicatedDataException(msg);
	}
}
void StudentContainer::remove(int number){
	list<tuple<Subject *, int>> l;
	list<Student>::iterator it = search(number);
	if(it != this->students.end()){
		l = this->enrolls->getSubjects(number);
		if(l.size() == 0){
			this->students.erase(it);
		}else{
			string msg = "Student: " + to_string(number);
			throw DataConsistencyException(msg);

		}
	}
}
void StudentContainer::update(int number, const string& name, const Date& date){
	list<Student>::iterator it = search(number);
	if(it != this->students.end()){
		it->setName(name);
		it->setBirthday(date);
	}
}
void StudentContainer::setEnrolls(EnrollContainer *enrolls) {
	this->enrolls = enrolls;
}



