/*
 * Enroll.cpp
 *
 *  Created on: 16/04/2021
 *      Author: pbs
 */

#include "Enroll.h"
#include "InvalidDataException.h"

bool Enroll::isPointerNotNull(void * ptr){
	if(ptr == NULL){
		return false;
	}
	return true;
}


Enroll::Enroll(int grade, Subject * subject, Student * student){
	this->setGrade(grade);
	this->setSubject(subject);
	this->setStudent(student);
}

Enroll::Enroll(const Enroll& obj){
	this->setGrade(obj.grade);
	this->setSubject(obj.subject);
	this->setStudent(obj.student);
}
Enroll::~Enroll(){

}

int Enroll::getGrade() const {
	return grade;
}

void Enroll::setGrade(int grade) {
	if(grade >=10){
		this->grade = grade;
	}else{
		string msg = "Enroll: grade = "+ to_string(grade);
		throw InvalidDataException(msg);
	}
}

Subject* Enroll::getSubject() const {
	return subject;
}

void Enroll::setSubject(Subject *subject) {
	if(isPointerNotNull(subject)==true){
		this->subject = subject;
	}else{
		string msg = "Enroll: subject = NULL";
		throw InvalidDataException(msg);
	}
}

Student* Enroll::getStudent() const{
	return this->student;
}
void Enroll::setStudent(Student *student){

	if(isPointerNotNull(student)==true){
		this->student = student;
	}else{
		string msg = "Enroll: student = NULL";
		throw InvalidDataException(msg);
	}

}

bool Enroll::operator == (const Enroll& obj) const{
	if((*(this->subject) == *(obj.subject)) && (*(this->student) == *(obj.student))){
		return true;
	}
	return false;
}



