/*
 * DataConsistencyException.cpp
 *
 *  Created on: 21/04/2021
 *      Author: pbs
 */


#include "DataConsistencyException.h"


DataConsistencyException::DataConsistencyException(string data){
	this->data = "Error: ["+ data + "] consistency!!";
}

const char* DataConsistencyException::what(){
	return this->data.c_str();
}



