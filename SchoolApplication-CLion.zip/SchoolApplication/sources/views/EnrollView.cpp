/*
 * EnrollView.cpp
 *
 *  Created on: 26/04/2021
 *      Author: pbs
 */




#include <iostream>
#include "EnrollView.h"
#include "Utils.h"
#include "InvalidDataException.h"
using namespace std;


Enroll EnrollView::getEnroll(StudentContainer & students, SubjectContainer & subjects){
	//this is very dangerous
	Enroll enroll(10,(Subject *)1,(Student *)1);
	bool flag = false;
	do{
		try{
			flag = false;
			cout<<"Enroll"<<endl;
			int number = Utils::getNumber("Enter Student Number");
			Student *student = students.get(number);
			enroll.setStudent(student);
			string initials = Utils::getString("Enter Subject Initials");
			Subject *subject = subjects.get(initials);
			enroll.setSubject(subject);
			int grade = Utils::getNumber("Enter Enroll Grade");
			enroll.setGrade(grade);

		}catch(InvalidDataException& e){
			flag = true;
		}
	}while(flag == true);
	return enroll;
}

void EnrollView::printEnroll(Enroll *enroll){
	Student *student = enroll->getStudent();
	Subject * subject = enroll->getSubject();
	cout<<to_string(student->getNumber())<<":"<<student->getName()<<":"<<subject->getInitials()<<":"<<subject->getDesignation()<<":"<<to_string(enroll->getGrade())<<endl;
}
void EnrollView::printEnrolls(list<Enroll>& enrolls){
	for (list<Enroll>::iterator it=enrolls.begin(); it != enrolls.end(); ++it){
		printEnroll(&*it);
	}
}

void EnrollView::printStudentEnrolls(Student * student, list<tuple<Subject *, int>>& subjects){
	cout<<to_string(student->getNumber())<<":"<<student->getName()<<endl;
	for (list<tuple<Subject *, int>>::iterator it=subjects.begin(); it != subjects.end(); ++it){
		tuple<Subject *, int> item = *it;
		Subject * subject = get<0>(item);
		int grade = get<1>(item);
		cout<<"\t"<<subject->getInitials()<<":"<<subject->getDesignation()<<":"<<to_string(grade)<<endl;
	}
}
void EnrollView::printSubjectEnrolls(Subject * subject, list<Student *>& students){
	cout<<subject->getInitials()<<":"<<subject->getDesignation()<<endl;
		for (list<Student *>::iterator it=students.begin(); it != students.end(); ++it){
			cout<<"\t"<<to_string((*it)->getNumber())<<":"<<(*it)->getName()<<endl;
		}
}

