/*
 * LectureView.cpp
 *
 *  Created on: 27/04/2021
 *      Author: pbs
 */



#include <iostream>
#include "LectureView.h"
#include "Utils.h"
#include "InvalidDataException.h"
#include "Lecture.h"
#include "SubjectContainer.h"

using namespace std;


Lecture LectureView::getLecture(SubjectContainer & subjects){
	//this is very dangerous
	Lecture lecture((Subject *)1);
	bool flag = false;
	do{
		try{
			flag = false;
			cout<<"Lecture"<<endl;
			string initials = Utils::getString("Enter Subject Initials");
			Subject *subject = subjects.get(initials);
			lecture.setSubject(subject);

		}catch(InvalidDataException& e){
			flag = true;
		}
	}while(flag == true);
	return lecture;
}

void LectureView::printLecture(Lecture *lecture){
	Subject * subject = lecture->getSubject();
	cout<<"\t"<<subject->getInitials()<<":"<<subject->getDesignation()<<endl;
}
void LectureView::printLectures(Instructor * instructor, list<Lecture>& lectures){
	cout<<instructor->getInitials()<<":"<<instructor->getName()<<endl;
	for (list<Lecture>::iterator it=lectures.begin(); it != lectures.end(); ++it){
		printLecture(&*it);
	}
}

