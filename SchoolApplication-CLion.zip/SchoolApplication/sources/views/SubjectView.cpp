/*
 * SubjectView.cpp
 *
 *  Created on: 26/04/2021
 *      Author: pbs
 */



#include <iostream>
#include "SubjectView.h"
#include "Utils.h"
#include "InvalidDataException.h"
using namespace std;


Subject SubjectView::getSubject(){
	Subject subject("XXXXX", "Temporary Name");
	bool flag = false;
	do{
		try{
			flag = false;
			cout<<"Subject"<<endl;
			string designation = Utils::getString("Designation");
			string initials = Utils::getString("Initials");
			subject.setDesignation(designation);
			subject.setInitials(initials);
		}catch(InvalidDataException& e){
			flag = true;
		}
	}while(flag == true);
	return subject;
}

void SubjectView::printSubject(Subject *subject){
	cout<<subject->getInitials()<<":"<<subject->getDesignation()<<endl;
}
void SubjectView::printSubjects(list<Subject>& subjects){
	for (list<Subject>::iterator it=subjects.begin(); it != subjects.end(); ++it){
		printSubject(&*it);
	}
}



