/*
 * InstructorView.cpp
 *
 *  Created on: 26/04/2021
 *      Author: pbs
 */



#include <iostream>
#include "InstructorView.h"
#include "Utils.h"
#include "InvalidDataException.h"
using namespace std;


Instructor InstructorView::getInstructor(){
	Instructor instructor("XXXX", "Temporary Name");
	bool flag = false;
	do{
		try{
			flag = false;
			cout<<"Instructor"<<endl;
			string name = Utils::getString("Name");
			string initials = Utils::getString("Initials");
			instructor.setName(name);
			instructor.setInitials(initials);
		}catch(InvalidDataException& e){
			flag = true;
		}
	}while(flag == true);
	return instructor;
}

void InstructorView::printInstructor(Instructor *instructor){
	cout<<instructor->getInitials()<<":"<<instructor->getName()<<endl;

}
void InstructorView::printInstructors(list<Instructor>& instructors){
	for (list<Instructor>::iterator it=instructors.begin(); it != instructors.end(); ++it){
		printInstructor(&*it);
	}
}

