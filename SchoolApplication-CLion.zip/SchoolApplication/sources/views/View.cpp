/*
 * View.cpp
 *
 *  Created on: 21/04/2021
 *      Author: pbs
 */
#include <iostream>

#include <list>
#include "View.h"
#include "Utils.h"
#include "InvalidDataException.h"
using namespace std;

View::View(){
}

int View::menuSchool() {
	int op = -1;
	do{
		cout<<"\n\n********** Menu School **********\n";
		cout<<"1 - Students\n";
		cout<<"2 - Instructors\n";
		cout<<"3 - Subjects\n";
		cout<<"4 - Enrolls\n";
		cout<<"\n0 - Exit\n";
		op = Utils::getNumber("Option");

	}while(op < 0 || op > 4);
	return op;
}
int View::menuStudents() {
	int op = -1;
	do{
		cout<<"\n\n********** Menu Student **********\n";
		cout<<"1 - Add\n";
		cout<<"2 - Find\n";
		cout<<"3 - Remove\n";
		cout<<"4 - Update\n";
		cout<<"5 - List\n";
		cout<<"\n0 - Exit\n";
		op = Utils::getNumber("Option");
	}while(op < 0 || op > 5);
	return op;
}
int View::menuInstructors() {
	int op = -1;
	do{
		cout<<"\n\n********** Menu Instructors **********\n";
		cout<<"1 - Add\n";
		cout<<"2 - Find\n";
		cout<<"3 - Remove\n";
		cout<<"4 - Update\n";
		cout<<"5 - List\n";
		cout<<"6 - Lectures\n";
		cout<<"\n0 - Exit\n";
		op = Utils::getNumber("Option");
	}while(op < 0 || op > 6);
	return op;
}



int View::menuSubjects() {
	int op = -1;
	do{
		cout<<"\n\n********** Menu Subjects **********\n";
		cout<<"1 - Add\n";
		cout<<"2 - Find\n";
		cout<<"3 - Remove\n";
		cout<<"4 - Update\n";
		cout<<"5 - List\n";
		cout<<"\n0 - Exit\n";
		op = Utils::getNumber("Option");
	}while(op < 0 || op > 5);
	return op;
}
int View::menuEnrolls() {
	int op = -1;
	do{
		cout<<"\n\n********** Menu Enrolls **********\n";
		cout<<"1 - Add\n";
		cout<<"2 - Find\n";
		cout<<"3 - Remove\n";
		cout<<"4 - List\n";
		cout<<"5 - List by student\n";
		cout<<"6 - List by subject\n";
		cout<<"\n0 - Exit\n";
		op = Utils::getNumber("Option");
	}while(op < 0 || op > 6);
	return op;
}
int View::menuLectures() {
	int op = -1;
	do{
		cout<<"\n\n********** Menu Lectures **********\n";
		cout<<"1 - Add\n";
		cout<<"2 - Remove\n";
		cout<<"3 - List\n";
		cout<<"\n0 - Exit\n";
		op = Utils::getNumber("Option");
	}while(op < 0 || op > 3);
	return op;
}





