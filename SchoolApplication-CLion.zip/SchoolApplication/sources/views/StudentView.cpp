/*
 * StudentView.cpp
 *
 *  Created on: 21/04/2021
 *      Author: pbs
 */

#include <iostream>
#include "StudentView.h"
#include "Utils.h"
#include "InvalidDataException.h"
using namespace std;

Date StudentView::getDate(){
	Date date;
	bool flag = false;
	do{
		try{
			flag = false;
			cout<<"Date"<<endl;
			int day = Utils::getNumber("Day");
			int month =  Utils::getNumber("Month");
			int year = Utils::getNumber("Year");
			date.setDate(day, month, year);
		}catch(InvalidDataException& e){
			flag = true;
		}
	}while(flag == true);
	return date;
}


Student StudentView::getStudent(){
	Date birthDay;
	Student student("Temporary Name", birthDay);
	bool flag = false;
	do{
		try{
			flag = false;
			cout<<"Student"<<endl;
			string name = Utils::getString("Name");
			birthDay = getDate();
			student.setName(name);
			student.setBirthday(birthDay);
		}catch(InvalidDataException& e){
			flag = true;
		}
	}while(flag == true);
	return student;
}

void StudentView::printStudent(Student *student){

	int day, month, year;
	student->getBirthday().getDate(day, month, year);
	string date = to_string(day)+"/"+to_string(month)+"/"+to_string(year);
	cout<<student->getNumber()<<":"<<student->getName()<<":"<<date<<endl;
}
void StudentView::printStudents(list<Student>& students){
	for (list<Student>::iterator it=students.begin(); it != students.end(); ++it){
		printStudent(&*it);
	}
}


